require 'test_helper'

class FbAgencyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
