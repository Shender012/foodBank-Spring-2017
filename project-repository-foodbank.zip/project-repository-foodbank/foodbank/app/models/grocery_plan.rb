class GroceryPlan < ActiveRecord::Base
    belongs_to :grocery_plans
    
end