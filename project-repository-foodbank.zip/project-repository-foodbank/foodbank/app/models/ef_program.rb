class EfProgram < ActiveRecord::Base
    belongs_to :ef_programs
    
end