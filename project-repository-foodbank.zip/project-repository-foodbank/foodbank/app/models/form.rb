class Form < ActiveRecord::Base
end

