class PartSixForm < ActiveRecord::Base
    belongs_to :part_six_forms
    
end