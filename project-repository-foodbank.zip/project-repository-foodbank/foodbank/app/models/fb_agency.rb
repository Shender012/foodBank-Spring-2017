class FbAgency < ActiveRecord::Base
    belongs_to :fb_agencies
  
    
end