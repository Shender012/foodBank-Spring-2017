class PartSevenEightForm < ActiveRecord::Base
    belongs_to :part_seven_eight_forms
    
end