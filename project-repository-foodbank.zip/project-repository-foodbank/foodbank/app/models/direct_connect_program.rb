class DirectConnectProgram < ActiveRecord::Base
    belongs_to :direct_connect_programs
    
end