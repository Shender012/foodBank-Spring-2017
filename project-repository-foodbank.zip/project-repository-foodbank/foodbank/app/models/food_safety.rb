class FoodSafety < ActiveRecord::Base
    belongs_to :food_safeties
    
end